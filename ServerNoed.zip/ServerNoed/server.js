var express = require('express')
var http = require('http')
var socketIO = require('socket.io')

var app = express()
var server = http.Server(app)
server.listen(5000)
var io = socketIO(server)
var Number = randomNumber()
var winnumber = 1;

io.on('connection', function (socket) {
    //console.log('client connected')
    
    socket.on('message.send', function (data) {
       var playerData = JSON.stringify(data);
       var player = JSON.parse(playerData);
       var number = player.number;
       var name = player.name;

        //console.log(name);
        //console.log(number);

        if (number == Number)
        {
            console.log(name + " " + "Correct" + " " + "Number" + " " + winnumber);
            socket.emit('playerwon', data)
            socket.broadcast.emit('playerwon', data)
            Number = randomNumber();
            winnumber++;
            console.log('Server Random Number is' + " " + Number)

        }
        if (number > Number){
            //console.log("Too High");
            socket.emit('high');
        } 
        if (number < Number){
            //console.log("Too Low");
            socket.emit('low');
        }
    });

});

console.log('server statred')

function randomNumber(){
    return Math.floor(Math.random() * 100 + 1)
}

console.log('Server Random Number is' + " " + Number)